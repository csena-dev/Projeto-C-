﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProjetoSistema
{
    public class LoginModel
    {
        private string login_usur;
        private string senha_usur;


        public string Login_Usur { get; set; }

        public string Senha_Usur { get; set; }
    }
}
